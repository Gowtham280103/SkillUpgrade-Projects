import React from "react";
import ReactDOM from "react-dom";
import App from "../src/Components/App/App";
<link
  href="https://fonts.googleapis.com/css?family=Montserrat:400,600&display=swap"
  rel="stylesheet"
/>;
ReactDOM.render(<App />, document.getElementById("root"));
